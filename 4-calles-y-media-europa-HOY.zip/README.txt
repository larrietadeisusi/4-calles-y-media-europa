INSTRUCCIONES RÁPIDAS

1. Sube estos archivos a tu repositorio de GitHub:
   index.html
   style.css
   script.js
   manifest.json
   carpeta iconos

2. Para probar hoy sin esperar al 27 de junio, abre:
   https://larrietadeisusi.github.io/4-calles-y-media-europa/?preview=1

3. Fotos:
   Sube tus fotos con estos nombres:
   fotos/dia1.jpg
   fotos/dia2.jpg
   ...
   fotos/dia22.jpg

4. Vídeos:
   El día 4 está preparado como vídeo:
   videos/dia4.mp4

5. Días 10, 11 y 16 están marcados como pendientes para retocar mañana.

6. Para instalar en iPhone:
   Safari > Compartir > Añadir a pantalla de inicio.
